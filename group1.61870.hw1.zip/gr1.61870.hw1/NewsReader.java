import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NewsReader {

	String[] news;
	StringBuilder updateFront = new StringBuilder();
	UnitsController controller = new UnitsController();
	
	public NewsReader(String[] news){
		this.news = news;
	}
	
	public void transformNews(){

		Pattern findCreateUnits = Pattern.compile("([a-zA-Z]*_*[a-zA-Z]*\\d*)\\s=\\s\\[(.*)\\]");
		Pattern findAttachUnit = Pattern.compile("([a-zA-Z]*_*[a-zA-Z]*\\d*)\\b attached to \\b([a-zA-Z]*_*[a-zA-Z]*\\d*)");
		Pattern findAttachUnitAfter = Pattern.compile("([a-zA-Z]*_*[a-zA-Z]*\\d*)\\b attached to \\b([a-zA-Z]*_*[a-zA-Z]*\\d*)\\b after soldier \\b(\\d*)");	
		Pattern findKillSoldiers = Pattern.compile("\\bsoldiers between \\b(\\d*)\\b and \\b(\\d*)\\b from \\b([a-zA-Z]*_*[a-zA-Z]*\\d*)\\b died heroically\\b");
		Pattern findKillSoldiers2 = Pattern.compile("\\bsoldiers \\b(\\d*)\\b..\\b(\\d*)\\b from \\b([a-zA-Z]*_*[a-zA-Z]*\\d*)\\b died heroically\\b");
		Pattern findShow = Pattern.compile("\\bshow \\b([a-zA-Z]*_*[a-zA-Z]*\\d*)");
		Pattern findShowSoldier= Pattern.compile("\\bshow soldier \\b(\\d*)");
		Pattern[] differentPatterns = {findCreateUnits, findAttachUnit, findAttachUnitAfter, findSoldiersDied, findSoldiersDied2, findShow, findShowSoldier};

		boolean matcherFindsPattern = false;
		int pattern_found = 0;
		

		for(int i = 0; i < news.length; i++){
			String newsI = news[i];
			Matcher matcher = null;
			for(int j = 0; j < differentPatterns.length; j++){
				matcher = differentPatterns[j].matcher(newsI);
				matcherFindsPattern = matcher.matches();
				if (matcherFindsPattern){ 
					pattern_found = j;
					break;	
				}
			}			 
			
			switch(pattern_found){
			case 0:
				controller.createUnits(matcher.group(1), matcher.group(2));
				break;
			case 1:
				controller.attachUnit(matcher.group(1), matcher.group(2));
				break;
			case 2:
				controller.attachUnitAfter(matcher.group(1), matcher.group(2), Integer.parseInt(matcher.group(3)));
				break;
			case 3:
				controller.killSoldiers(Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)), matcher.group(3));
				break;	
			case 4:
				controller.killSoldiers(Integer.parseInt(matcher.group(1)), Integer.parseInt(matcher.group(2)), matcher.group(3));
				break;
			case 5:
				updateFront.append(controller.show(matcher.group(1)));
				break;	
			case 6:
				updateFront.append(controller.show(Integer.parseInt(matcher.group(1))));
				break;	
			}
		}		
	}
	
	public String getUpdateFront(){
		return updateFront.toString();
	}
	
}

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class UnitsController{

	Hashtable<String, ArrayList<Integer>> unitsStorage = new Hashtable<String, ArrayList<Integer>>();
	Hashtable<String, String> unitAttachments = new Hashtable<String, String>();
	Hashtable<String, ArrayList<String>> unitsHierarchy = new Hashtable<String, ArrayList<String>>();
	NewsReader updatedNews;
	
	public UnitsController(){
	
	}
	
	//creates a Hashtable where keys are unit's names and values are ArrayLists of soldiers that they contain
	public void createUnits(String unitName, String soldiers){
		//creates an array that contains the soldiers' name as String
		String[] stringArray = soldiers.split("\\s*,\\s*");
		String emptyString = ""; 
		
		//creates an array that contains the soldiers' name as int
		int length = stringArray.length;
		ArrayList<Integer> intArray = new ArrayList<Integer>();
		
		if(!soldiers.equals(emptyString)){
			for(int i = 0; i < length; i++){
				intArray.add(Integer.parseInt(stringArray[i]));
			}
		}
		unitsStorage.put(unitName, intArray);		
	} 
	
	//puts the soldiers in unitName1 into unitName2
	public void attachUnit(String unitName1, String unitName2){
		if(unitAttachments.get(unitName1) != unitName2){
			removeFirstAttachment(unitName1);
			unitsStorage.get(unitName2).addAll(unitsStorage.get(unitName1));
			
			unitAttachments.put(unitName1, unitName2);
			putsIntoHierarchy(unitName1, unitName2);
			linkedUnitsHierarchy(unitName1, unitName2);
		}
	}
	
	//puts the soldiers in unitName1 into unitName2 after a specific soldier if it's possible
	public void attachUnitAfter(String unitName1, String unitName2, int soldierAfter){
		int soldierName = unitsStorage.get(unitName2).indexOf(soldierAfter) + 1;
		int unitSize = unitsStorage.get(unitName2).size();
		int middle = (unitSize % 2 == 0) ? unitSize / 2 :  unitSize / 2 + 1;
	
		if (soldierName != middle){
			removeFirstAttachment(unitName1);
			
			ArrayList<Integer> toBeAttached = new ArrayList<Integer>();
			toBeAttached = unitsStorage.get(unitName1);
			
			for(int i = 0; i < toBeAttached.size(); i++){
				unitsStorage.get(unitName2).add(soldierName + i, toBeAttached.get(i));
			}
		
		unitAttachments.put(unitName1, unitName2);
		putsIntoHierarchy(unitName1, unitName2);
		linkedUnitsHierarchy(unitName1, unitName2);
		}
	}
	
	//remove soldiers from the attaching unit
	private void removeFirstAttachment(String unitName1){
		if(unitAttachments.containsKey(unitName1)){
			removeAfterSecondAttachment(unitName1);
			unitsHierarchy.get(unitAttachments.get(unitName1)).remove(unitName1);
		}
	}

	//remove soldiers when they have to be attached again
	private void removeAfterSecondAttachment(String unitName1){
		ArrayList<Integer> removed = new ArrayList<Integer>();
		removed = unitsStorage.get(unitName1);
		for (int i = 0; i < removed.size(); i++){
			unitsStorage.get(unitAttachments.get(unitName1)).remove(removed.get(i));
		}
	}
	
	//puts units into the hierarchy after attachment
	private void putsIntoHierarchy(String unitName1, String unitName2){
		if(unitsHierarchy.containsKey(unitName2)){
			unitsHierarchy.get(unitName2).add(unitName1);
		}
		else {
			ArrayList<String> arr = new ArrayList<String>();
			arr.add(unitName1);
			unitsHierarchy.put(unitName2, arr);
		}
	}

	private void linkedUnitsHierarchy(String unitName1, String unitName2){
		if(unitAttachments.containsKey(unitName2)){
			unitsStorage.get(unitAttachments.get(unitName2)).addAll(unitsStorage.get(unitName1));
		}
	}
	
	//kill soldiers
	public void killSoldiers(int from, int to, String unitName){
		for(int i = from; i <= to; i++){
			unitsStorage.get(unitName).remove(new Integer(i));
			ArrayList<String> inHierarchy = new ArrayList<String>();
			inHierarchy = unitsHierarchy.get(unitName);
			if(unitsHierarchy.containsKey(unitName)){
				for(int j = 0; j < inHierarchy.size(); j++){
					String name = inHierarchy.get(j);
					unitsStorage.get(name).remove(new Integer(i));
					killSoldiers(from, to, inHierarchy.get(j));
				}
			}
		}
	}
	
	//shows soldiers in unitName
	public String show(String unitName){
		String result;
		result = "[";
		Iterator<Integer> it = unitsStorage.get(unitName).iterator();
		while(it.hasNext()){
			result = result + it.next();
			if(it.hasNext()){
				result = result + ", ";
			}
		}
		result = result + "]\n";
		
		return result;	
	}
	
	//shows all the units that contain soldierName
	 public String show(int soldierName){

		StringBuilder result = new StringBuilder();
		
		Enumeration<String> enumKey = unitsStorage.keys();
		boolean flag = true;

		while(enumKey.hasMoreElements()) {
		    String key = enumKey.nextElement();
		    ArrayList<Integer> value = unitsStorage.get(key);
		    
		    if(value.contains(soldierNumber) && flag){
				result.append(key);
				flag = false;
			} else if(value.contains(soldierNumber)) {
				result.append(", " + key);
			}
		}	
		result.append("\n");
		return result.toString();
	}

}
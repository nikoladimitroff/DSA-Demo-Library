interface IFrontBookkeeper {
    String updateFront(String[] news);
}

public class FrontBookkeeper61870 implements IFrontBookkeeper {
	
	public FrontBookkeeper61870(){
	
	}
	
	public String updateFront(String[] news) {
	    NewsReader updatedNews = new NewsReader(news); 
	    updatedNews.transformNews();
	    String result = updatedNews.getUpdateFront();
		return result;
	}
	
}


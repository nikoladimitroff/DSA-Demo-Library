package ibookindexer;

public interface IBookIndexer {

    public void buildIndex(String bookFilePath, String[] keywords, String indexFilePath);

}

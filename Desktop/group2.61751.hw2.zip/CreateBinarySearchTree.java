package ibookindexer;

import java.util.ArrayList;

public class CreateBinarySearchTree {

    public CreateBinarySearchTree left;
    public CreateBinarySearchTree right;

    private String word;
    private ArrayList<Integer> value;

    public CreateBinarySearchTree(String word) {
        this.word = word;
        this.value = new ArrayList<>();
    }

    public void add(String word) {
        if (word.compareTo(this.word) < 0) {
            if (this.left == null) {
                this.left = new CreateBinarySearchTree(word);
                return;
            }
            this.left.add(word);
        } else if (word.compareTo(this.word) > 0) {
            if (this.right == null) {
                this.right = new CreateBinarySearchTree(word);
                return;
            }
            this.right.add(word);
        } else {
            this.value = new ArrayList<>();
        }
    }

    public ArrayList<Integer> get(String word) {
        if (word.compareTo(this.word) < 0) {
            if (this.left == null) {
                return null;
            } else {
                return this.left.get(word);
            }
        } else if (word.compareTo(this.word) > 0) {
            if (this.right == null) {
                return null;
            } else {
                return this.right.get(word);
            }
        } else {
            return this.value;
        }
    }

    public void find(String word, int pageNumber) {
        if (word.compareTo(this.word) < 0) {
            if (this.left == null) {

            } else {
                this.left.find(word, pageNumber);
            }
        } else if (word.compareTo(this.word) > 0) {
            if (this.right == null) {

            } else {
                this.right.find(word, pageNumber);
            }
        } else {
            if (value.size() > 0 && value.get(value.size() - 1) == pageNumber) {
            } else {
                value.add(pageNumber);
            }
        }
    }

}

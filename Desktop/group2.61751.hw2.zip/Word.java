package ibookindexer;

import java.util.ArrayList;

public class Word {

    private String word;
    private ArrayList vector;

    Word(String word, ArrayList vector) {
        this.word = word;
        this.vector = vector;
    }

    public String getWord() {
        return word;
    }

    public ArrayList getVector() {
        return vector;
    }

}

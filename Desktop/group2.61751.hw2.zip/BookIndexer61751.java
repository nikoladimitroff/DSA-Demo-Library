package ibookindexer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BookIndexer61751 implements IBookIndexer {

    @Override
    public void buildIndex(String bookFilePath, String[] keywords, String indexFilePath) {
        Arrays.sort(keywords);
        if (keywords.length != 0) {
            CreateBinarySearchTree keywordsBST = new CreateBinarySearchTree(keywords[ (keywords.length - 1) / 2].toLowerCase());
            populate(keywords, keywordsBST, 0, (keywords.length - 1) / 2 - 1);
            populate(keywords, keywordsBST, (keywords.length - 1) / 2 + 1, keywords.length - 1);
            ArrayList<Page> book = null;
            try {
                book = HandlingData.readFile(bookFilePath);
            } catch (IOException ex) {
                Logger.getLogger(BookIndexer61751.class.getName()).log(Level.SEVERE, null, ex);
            }
            for (Iterator<Page> it = book.iterator(); it.hasNext();) {
                Page page = it.next();
                for (String word : page.getContent()) {
                    keywordsBST.find(word, page.getNumber());
                }
            }
            HandlingData.writeIndex(indexFilePath, keywordsBST, keywords);
        }
    }

    private void populate(String[] keywords, CreateBinarySearchTree keywordsBST, int start, int end) {
        int mid = Math.abs(end - start) / 2;
        if (Math.abs(end - start + 1) > 3) {
            keywordsBST.add(keywords[start + mid].toLowerCase());
            populate(keywords, keywordsBST, start, start + mid - 1);
            populate(keywords, keywordsBST, start + mid + 1, end);
        } else {
            if (mid == 1) {
                keywordsBST.add(keywords[start + mid].toLowerCase());
            }
            keywordsBST.add(keywords[start].toLowerCase());
            if (end != start + mid && end != start) {
                keywordsBST.add(keywords[end].toLowerCase());
            }
        }
    }

}

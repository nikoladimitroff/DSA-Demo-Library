package ibookindexer;

public class Page {

    private String[] pageContent;
    private int pageNumber;

    Page(String[] pageContent, int pageNumber) {
        this.pageContent = pageContent.clone();
        this.pageNumber = pageNumber;
    }

    public String[] getContent() {
        return pageContent;
    }

    public int getNumber() {
        return pageNumber;
    }
}

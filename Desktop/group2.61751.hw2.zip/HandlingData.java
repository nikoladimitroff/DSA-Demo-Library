package ibookindexer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;

public class HandlingData {

    public static ArrayList<Page> readFile(String FilePath) throws IOException {
        BufferedReader count = new BufferedReader(new FileReader(FilePath));
        ArrayList<Page> book = new ArrayList<>();
        int currentPage = 0;
        String temp = "";
        int index = -1;
        String line = null;
        while ((line = count.readLine()) != null) {
            if (line.contains("=== Page ") && line.contains(" ===")) {
                if (index >= 0) {
                    temp = temp.toLowerCase();
                    book.add(new Page(temp.split("[ -]"), currentPage));
                    temp = "";
                }
                index++;
                currentPage = Integer.parseInt(line.replace("=== Page ", "").replace(" ===", ""));
            } else {
                temp = temp + line;
            }

        }
        temp = temp.toLowerCase();
        book.add(new Page(temp.split("[ -]"), currentPage));
        count.close();
        return book;
    }

    public static void writeIndex(String IndexPath, CreateBinarySearchTree index, String[] keys) {
        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(IndexPath), "utf-8"));
            writer.write("INDEX");
            for (String wordInIndex : keys) {
                ArrayList<Integer> tmp = index.get(wordInIndex);
                if (tmp.size() > 0) {
                    String tmp1 = System.getProperty("line.separator");
                    tmp1 += wordInIndex;
                    for (int s = 0; s < tmp.size(); s++) {
                        tmp1 += String.format(", %d", tmp.get(s));
                        if (s + 1 < tmp.size() && tmp.get(s) == tmp.get(s + 1) - 1) {
                            s++;
                            while (s + 1 < tmp.size() && tmp.get(s) == tmp.get(s + 1) - 1) {
                                s++;
                            }
                            tmp1 += String.format("-%d", tmp.get(s));
                        }
                    }
                    writer.write(tmp1);
                }
            }
        } catch (IOException ex) {

        } finally {
            try {
                writer.close();
            } catch (IOException ex) {
            }
        }
    }
}

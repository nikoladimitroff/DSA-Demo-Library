package bookindexer61720;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Ekaterina Goranova
 */
public class BookIndexer61720{
 
    public void buildIndex(String bookFilePath, String[] keywords, String indexFilePath) throws IOException{
        HashMap<String, List<Integer>> index = new HashMap<String, List<Integer>>();
        BufferedReader textReader = new BufferedReader(new FileReader(bookFilePath));
        
        for(String keyword : keywords) {
            List<Integer> ar = new ArrayList<Integer>();
            index.put(keyword.toLowerCase(), ar);
        }
        
        String aLine;
        while ((aLine = textReader.readLine()) != null) {
            Integer pageNmb = getPageNumber(aLine);
            if(pageNmb == null) continue;
            
            String[] words = textReader.readLine().toLowerCase().split("[[ ]*|[,]*|[:]*|[;]*|[!]*|[?]*]+");
            for(String word : words) {
                if(index.containsKey(word)) {
                    List<Integer> pages = index.get(word);
                    if(!pages.contains(pageNmb)) {
                        pages.add(pageNmb);
                        index.put(word, pages);
                    }
                }
            }            
        }
        textReader.close();
        
        File file = new File(indexFilePath);
        BufferedWriter output = new BufferedWriter(new FileWriter(file));
        output.write(constructIndex(index));
        output.close();
    }
    
    private Integer getPageNumber(String line) {
        Pattern regex = Pattern.compile("^=== Page (\\d+) ===$");
        Matcher m = regex.matcher(line);
        if(m.find()) {
            return Integer.valueOf(m.group(1));
        }
        return null;
    }
    
    private String constructIndex(HashMap<String, List<Integer>> index) {
        String output = "INDEX\n";
        for(Map.Entry<String, List<Integer>> line : index.entrySet()) {
            output += line.getKey() + pageNmbToString(line.getValue()) + "\n";
        }
        return output;
    }
    
    private String pageNmbToString(List<Integer> pages) {
        String output = ", " + pages.get(0);
        Integer last = null;
        for(int i = 1, size = pages.size(); i < size; i++) {
            if(pages.get(i) - pages.get(i - 1) == 1) {
                last = pages.get(i);
            } else {
                if(last != null) {
                    output += "-" + last;
                    last = null;
                }
                output += ", " + pages.get(i);
            }
        }
        if(last != null) {
            output += "-" + last;
        }
        return output;
    }
}

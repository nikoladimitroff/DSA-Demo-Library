package fileencoder61720;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author Ekaterina Goranova
 */
public class FileEncoder61720 {

    /**
     * Encodes a file with the specified key and saves the result to a given file.
     * @param sourceFile - path to the initial file
     * @param destinationFile - path to the result file
     * @param key - list of replacement bytes
     */
    public void encode(String sourceFile, String destinationFile, LinkedList<Character> key){
        ArrayList<Integer> byteKey = new ArrayList<Integer>();
        for (char c : key) {
             byteKey.add((int) c);
        }
       
        try
        {
            File in = new File(sourceFile);
            FileInputStream inputStream = new FileInputStream(in);
            byte[] fileContent = new byte[(int)in.length()];
            inputStream.read(fileContent);
            inputStream.close();
               
            File out = new File(destinationFile);  
            FileOutputStream outputStream = new FileOutputStream(out);
            for (int i = 0; i < fileContent.length; i++){
                int b = fileContent[i];
                if (isPrime(i)) {
                    outputStream.write(b);
                } else {
                    outputStream.write(byteKey.get(b & 0xff));
                }
            }
            outputStream.close();
        } 
        catch (FileNotFoundException e) {
            System.out.println("File not found" + e);
        }
        catch(IOException ioe)
        {
            System.out.println("Exception while reading the file " + ioe);
        }
    }

    /**
     * Decodes a file that was encoded with the above algorithm.
     * @param encodedFile - path to encoded file
     * @param destinationFile - path to the result file
     * @param key - list of replacement bytes that were used to encode the file
     */
    public void decode(String encodedFile, String destinationFile, LinkedList<Character> key){
        ArrayList<Integer> byteKey = new ArrayList<Integer>();
        for (char c : key) {
             byteKey.add((int) c);
        }
       
        try
        {
            File in = new File(encodedFile);
            FileInputStream inputStream = new FileInputStream(in);
            byte[] fileContent = new byte[(int)in.length()];
            inputStream.read(fileContent);
            inputStream.close();
               
            File out = new File(destinationFile);  
            FileOutputStream outputStream = new FileOutputStream(out);
            for (int i = 0; i < fileContent.length; i++){
                int b = fileContent[i];
                if (isPrime(i)) {
                    outputStream.write(b);
                } else {
                    outputStream.write(byteKey.indexOf(b & 0xff));
                }
            }
            outputStream.close();
        } 
        catch (FileNotFoundException e) {
            System.out.println("File not found" + e);
        }
        catch(IOException ioe)
        {
            System.out.println("Exception while reading the file " + ioe);
        }
    }
        
    public static boolean isPrime(int number) {
        if (number == 2 || number == 3) {
            return true;
        }
        if (number % 2 == 0) {
            return false;
        }
        int sqrt = (int) Math.sqrt(number) + 1;
        for (int i = 3; i < sqrt; i += 2) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }
    
}

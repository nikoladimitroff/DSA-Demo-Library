package fileencoder61710;

import java.io.File;
import java.util.LinkedList;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Hashtable;
import java.util.ListIterator;

/**
 *
 * @author Dell
 */
public class FileEncoder61710 {

    public static boolean isPrime(int n) {
      int sqrtN = (int) Math.sqrt(n);
      boolean[] isComposite = new boolean[n + 1];
      for (int i = 2; i <= sqrtN; i++) {
            if (!isComposite[i]) {
                  for (int j = i * i; j <= n; j += i)
                        isComposite[j] = true;
            }
      }
        return !isComposite[n];
    }
    
    public static Hashtable<Integer, Character> convertToHashTable(LinkedList<Character> keys) {
        Hashtable<Integer, Character> result = new Hashtable();
        ListIterator<Character> iterator = keys.listIterator();
        int i = 0;
        while(iterator.hasNext()) {
            result.put(i, iterator.next());
            i++;
        }
        return result;
    }

    /**
     * Encodes a file with the specified key and saves the result to a given
     * file.
     *
     * @param sourceFile - path to the initial file
     * @param destinationFile - path to the result file
     * @param key - list of replacement bytes
     */
    public static void encode(String sourceFile, String destinationFile, LinkedList<Character> key) {
        Hashtable<Integer, Character> result = convertToHashTable(key);
        int currentByte;
        byte[] allBytes = null;

        try {
            FileInputStream in = new FileInputStream(new File(sourceFile));
            FileOutputStream out = new FileOutputStream(new File(destinationFile));

            while((currentByte = in.read()) != -1) {
                allBytes = Files.readAllBytes(Paths.get(sourceFile));
            }
            for(int i = 0; i < allBytes.length; i++) {
                if(isPrime(i) && i != 0) {
                    out.write(allBytes[i]);
                }
                else {
                    out.write(result.get(allBytes[i] & 0xff));
                }
            }
            
            if( in != null) {
                in.close();
            }

            if( out != null) {
                out.close();
            }
            
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Decodes a file that was encoded with the above algorithm.
     *
     * @param encodedFile - path to encoded file
     * @param destinationFile - path to the result file
     * @param key - list of replacement bytes that were used to encode the file
     */
    public static void decode(String encodedFile, String destinationFile, LinkedList<Character> key) {
        Hashtable<Integer, Character> result = convertToHashTable(key);
        int currentByte;
        byte[] allBytes = null;

        try {
            FileInputStream in = new FileInputStream(new File(encodedFile));
            FileOutputStream out = new FileOutputStream(new File(destinationFile));

            while((currentByte = in.read()) != -1) {
                allBytes = Files.readAllBytes(Paths.get(encodedFile));
            }
            for(int i = 0; i < allBytes.length; i++) {
                if(isPrime(i) && i != 0) {
                    out.write(allBytes[i]);
                }
                else {
                    out.write(result.get(allBytes[i] & 0xff));
                }
            }
            
            if( in != null) {
                in.close();
            }

            if( out != null) {
                out.close();
            }
            
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}

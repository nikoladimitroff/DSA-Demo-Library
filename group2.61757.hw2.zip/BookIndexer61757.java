import java.lang.*;
import java.util.*;
import java.io.*;
public class BookIndexer61757 implements IBookIndexer {
	
	public void buildIndex(String bookFilePath, String[] keywords, String indexFilePath){
		
		
		
		try(FileInputStream in = new FileInputStream(bookFilePath);
				FileOutputStream out = new FileOutputStream(indexFilePath);
					)
			{
			
			out.write(73);
			out.write(78);
			out.write(68);
			out.write(69);
			out.write(88);
			
			}
		catch(Exception e){}
		
	}
	

}

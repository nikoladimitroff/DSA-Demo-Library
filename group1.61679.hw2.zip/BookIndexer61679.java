import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;


public class BookIndexer61679 implements IBookIndexer {
	
	@Override
	public void buildIndex(String bookFilePath, String[] keywords, String indexFilePath) {
		Arrays.sort(keywords, (x, y)-> x.compareTo(y));

		InputStream inputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader reader = null;

		OutputStream outputStream = null;
		OutputStreamWriter outputStreamWriter = null;
		BufferedWriter writer = null;

		String lineString;
		StringBuilder sb;
		String [] getCountsByWord = new String[keywords.length];
		
		for (int i = 0; i < getCountsByWord.length; i++) {
			getCountsByWord[i] = "";
		}
		
		int currentPage = 1;

		try {
			inputStream = new FileInputStream(bookFilePath);
			inputStreamReader = new InputStreamReader(inputStream);
			reader = new BufferedReader(inputStreamReader);

			while ((lineString  = reader.readLine().toLowerCase()) != null ) {
				if (lineString.startsWith("=== page ") && lineString.endsWith(" ===")) {
					String[] numberOfWords = lineString.trim().split("\\s+"); 
					currentPage = Integer.parseInt(numberOfWords[2]);
				} else {
					for (int i = 0; i < keywords.length; i++) {
						String searchedWord = keywords[i]; 
						if (Arrays.stream(lineString
								.split("[[ ]*|[,]*|[:]*|[;]*|[!]*|[?]*]+"))
								.filter(x -> x.equals(searchedWord))
								.count() >= 1){
							getCountsByWord[i] += (String.valueOf(currentPage) + ",");
						}
					}
				}
			}
		} catch ( Exception e) {
			e.getStackTrace();
		} finally {
			if ( inputStream != null ){
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if ( inputStreamReader != null ){
				try {
					inputStreamReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			if ( reader != null ){
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		for (int i = 0; i < getCountsByWord.length; i++) {
			
			HashMap<Integer, String> getPage = new LinkedHashMap<>();
			String[] wordToString = getCountsByWord[i].split(",");
			sb = new StringBuilder();
			
			for (int j = 0; j < wordToString.length; j++) {
				if(wordToString[j] != ""){
					getPage.put(Integer.parseInt(wordToString[j]), null);
				}
			}

			List<Integer> list = getPage
					.keySet()
					.stream()
					.sorted((x, y) -> x.compareTo(y))
					.collect(Collectors.toList());
			Iterator<Integer> itr = list.iterator();

			int[] arrInt = new int [list.size()];
			int index = -1;
			sb = new StringBuilder(arrInt.length + 1);
			while (itr.hasNext()) {
				arrInt[++index] = itr.next();
			}

			sb.append(keywords[i] + ", ");
			int j;

			for (int k = 0; k < arrInt.length; k += j) {
				j = 1;
				while (( k + j ) < arrInt.length && arrInt[k] + j == arrInt[k + j]) {
					j ++;
				}
				if (j > 1){
					if (k + j  >=  arrInt.length) {
						sb.append(String.valueOf(arrInt[k]) + "-" + String.valueOf(arrInt[ k + j - 1]));
					} else {
						sb.append(String.valueOf(arrInt[k]) + "-" + String.valueOf(arrInt[ k + j - 1]) + ", ");
					}
				} else {
					if (k + 1 < arrInt.length){
						sb.append(String.valueOf(arrInt[k]) + ", ");
					} else {
						sb.append(String.valueOf(arrInt[k]));
					}
				}
			}
			getCountsByWord[i] = new String(sb);
		}

		try {
			outputStream = new FileOutputStream(indexFilePath);
			outputStreamWriter = new OutputStreamWriter(outputStream);
			writer = new BufferedWriter(outputStreamWriter);
			writer.write("INDEX");
			writer.newLine();
			for (int j = 0; j < getCountsByWord.length; j++) {
				writer.write(getCountsByWord[j]);
				writer.newLine();
			}
			writer.flush();
		} catch (IOException ex) {
			ex.getStackTrace();
		} finally {
			if (outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (outputStreamWriter != null){
				try {
					outputStreamWriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (writer != null ){
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
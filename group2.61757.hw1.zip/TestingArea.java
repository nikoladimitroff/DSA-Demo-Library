package hwk1;
import java.io.*;
import java.util.*;
public class TestingArea  {
	public static void main (String[] args) throws IOException{
		FileEncoder61757 test = new FileEncoder61757();
		LinkedList<Character> key = new LinkedList<Character>();
		for(int i=255;i>=0;i--){
			key.add((char)i);
		}
		
		test.encode("E:\\test.gif", "E:\\nociq.gif", key);
		test.decode("E:\\nociq.gif", "E:\\molq.gif", key);
		
	}

}

package hwk1;
import java.util.*;
import java.io.*;
public interface FileEncoderFN   {
	
	public void encode(String sourceFile,String destinationFile,LinkedList<Character> key);
	public void decode(String encodedFile, String destinationFile, LinkedList<Character> key);
	

}

package hwk1;

import java.lang.*;
import java.util.*;
import java.io.*;

public class FileEncoder61757 implements FileEncoderFN{
	
	public void encode(String sourceFile,String destinationFile,LinkedList<Character> key){
	
		List<Character> myList = new ArrayList<Character>(key);
	try(FileInputStream in = new FileInputStream(sourceFile);
		FileOutputStream out = new FileOutputStream(destinationFile);
			)
	{
		char b;
		
		
			for(int i=0;i<in.getChannel().size();i++){
				b= (char)in.read() ;
				if(isPrime(i) || i==1){
					out.write(b);
				}
				else{
					out.write((char)(myList.get((int)b)));
				}
				
			}
			
			
			
			
			//out.write(c);
		
		
	} catch (Exception e) {
		
	}
	
	}
	
	public void decode(String encodedFile, String destinationFile, LinkedList<Character> key){
		

		
		List<Character> myList = new ArrayList<Character>(key);
	try(FileInputStream in = new FileInputStream(encodedFile);
		FileOutputStream out = new FileOutputStream(destinationFile);
			)
	{
		char b;
		
		
			for(int i=0;i<in.getChannel().size();i++){
				b= (char)in.read();
				if(isPrime(i) || i==1){
					out.write(b);
				}
				else{
					
					for(int j=0;j<myList.size();j++){
						if((char)myList.get(j)==b){
							out.write((char)j);
						}
					}
					
				}
				
			}
			
			
			
			
			//out.write(c);
		
		
	} catch (Exception e) {
		
	}
	
	
		
	}
	
	
	
	
	boolean isPrime(long n) {
	    if(n < 2) return false;
	    if(n == 2 || n == 3) return true;
	    if(n%2 == 0 || n%3 == 0) return false;
	    long sqrtN = (long)Math.sqrt(n)+1;
	    for(long i = 6L; i <= sqrtN; i += 6) {
	        if(n%(i-1) == 0 || n%(i+1) == 0) return false;
	    }
	    return true;
	}
}


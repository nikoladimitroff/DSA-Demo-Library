package software;

import java.util.*;
import java.io.*;
import java.math.*;
import java.nio.*;
import java.nio.file.*;


public class FileEncoder61660 {

    public static byte[] convertToBytesUsingByteBuffer(int value)
    {
        ByteBuffer buffer = ByteBuffer.allocate(4);
        buffer.order(ByteOrder.BIG_ENDIAN);
        return buffer.putInt(value).array();
    }

    public void encode(String sourceFile, String destinationFile, LinkedList<Character> key)
    {
        List<Character> keys = new ArrayList<Character>(key);

        Path path = Paths.get(sourceFile);

        try {
            FileOutputStream stream = new FileOutputStream(destinationFile);

            byte[] data = Files.readAllBytes(path);

            for(int i = 0; i < data.length; i++)
            {
                if(!isPrime(i) && i != 1)
                {
                    int index = data[i] - '0';
                    int number = (int)key.get(index);


//                    byte[] bytes = BigInteger.valueOf(number).toByteArray();
//                    byte[] bytes = convertToBytesUsingByteBuffer(100);

                    int intValue = 566;

                    byte[] bytes = new byte[4];

                    bytes[0] = (byte)(number >> 24);
                    bytes[1] = (byte)(number >> 16);
                    bytes[2] = (byte)(number >> 8);
                    bytes[3] = (byte)number;

                    stream.write(bytes);
                }
                else
                {
                        stream.write(data[i]);
                }
            }

            stream.write(123);
            stream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void decode(String encodedFile, String destinationFile, LinkedList<Character> key)
    {
        this.encode(encodedFile, destinationFile, key);
    }

    //First Version
    private boolean isPrime(int number) {
        if (number == 0) return false;
        int sqrt = (int) Math.sqrt(number) + 1;
        for (int i = 2; i < sqrt; i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;
    }

    public LinkedList<Character> toListCharecter() {
        LinkedList<Character> ak = new LinkedList<Character>();
        //123 101 111 222 251 42
        ak.add(Character.toChars(123)[0]);
        ak.add(Character.toChars(101)[0]);
        ak.add(Character.toChars(111)[0]);
        ak.add(Character.toChars(222)[0]);
        ak.add(Character.toChars(251)[0]);
        ak.add(Character.toChars(42)[0]);
        return ak;
    }

    public void createFile()
    {
        String destinationFile = "output.txt";
        byte [] data = new byte[]{4, 3, 2, 0, 5};
        try {
            Files.write(Paths.get(destinationFile), data, StandardOpenOption.CREATE);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
        FileEncoder61660 test = new FileEncoder61660();
        test.createFile();

        String sourceFile = "input.txt";
        String destinationFile = "output.txt";

        LinkedList<Character> testList = test.toListCharecter();
        long startTime = System.currentTimeMillis();
        test.encode(sourceFile, destinationFile, testList);
        long endTime = System.currentTimeMillis();

        System.out.println("Took "+(endTime - startTime) + " ms");
//        test.decode(sourceFile, destinationFile, testList);
    }

}